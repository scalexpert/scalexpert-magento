# Contributing to Scalexpert for Magento 2

Anyone is welcome to contribute to Scalexpert for Magento 2. There are various ways you can contribute:

- Raise an issue on GitHub.
- Send us a Pull Request on **develop** branch with your bug fixes.
- Fork your own copy of the repository to add new features.
- Provide feedback and suggestions on enhancements.
