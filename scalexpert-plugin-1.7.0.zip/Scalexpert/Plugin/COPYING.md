Copyright © 2023-2024 Société Générale.

Scalexpert plugin for Magento 2 is licensed under the
Open Software License version 3.0 that is bundled with
this package in the file LICENSE.txt. It is also
available through the world-wide-web at this URL:
https://opensource.org/licenses/osl-3.0.php
