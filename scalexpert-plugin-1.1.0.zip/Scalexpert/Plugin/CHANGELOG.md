1.0.0, 2023-10-15:
=============

    delivery of version 1.0.0 of plugin Magento CE & EE 2.4.3, 2.4.4 , 2.4.6
    content: e-financing solutions split payment & long term credit

1.1.0, 2023-11-10:
=============

    add insurance
    Bug fix: fix succes page for guest orders
