<?php
namespace Scalexpert\Plugin\Logger;

class Logger extends \Monolog\Logger
{
}
