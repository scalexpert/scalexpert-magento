<?php

namespace Scalexpert\Plugin\Controller\Adminhtml\Ajax;

interface FlushableConfigField
{
    public function flushCache();
}
